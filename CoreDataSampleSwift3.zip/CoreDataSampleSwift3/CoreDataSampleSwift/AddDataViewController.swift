//
//  AddDataViewController.swift
//  CoreDataSampleSwift
//
//  Created by Salute on 09/10/16.
//  Copyright © 2016 RedSalute. All rights reserved.
//

import UIKit

class AddDataViewController: UIViewController {

    
   
    @IBOutlet weak var txtField: UITextField!
    @IBOutlet weak var isImp: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func addTask(_ sender: AnyObject) {
        let persContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let task = Task(context: persContext)
        task.name = txtField.text!
        task.isImportant = isImp.isOn
        //Save the data
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        navigationController!.popViewController(animated: true)
    }
    }
