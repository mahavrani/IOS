//
//  ViewController.swift
//  CoreDataSampleSwift
//
//  Created by Salute on 09/10/16.
//  Copyright © 2016 RedSalute. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var tasks :[Task] = []
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
        tableView.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        //Get the data 
         getData()
        //Reload the tableview
        tableView.reloadData()
    }
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let task = tasks[indexPath.row]
        if(task.isImportant){
            cell.textLabel?.text = "👉 \(task.name!)"
        }
        else{
        cell.textLabel?.text = task.name!
        }
        
        return cell
    }
    
    func getData(){
        
        let persContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            tasks = try persContext.fetch(Task.fetchRequest())
        }
        catch{
            print("Fetch Failed")
        }
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let persContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        if editingStyle == .delete {
            let task = tasks[indexPath.row]
            persContext.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            do {
                tasks = try persContext.fetch(Task.fetchRequest())
            }catch {
                print("Fetch Failed After Delete")
            }
        }
        tableView.reloadData()
    }
   
}

