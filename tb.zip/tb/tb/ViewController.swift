//
//  ViewController.swift
//  tb
//
//  Created by Salute on 20/11/16.
//  Copyright © 2016 RedSalute. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableViewInsideCell: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//         self.tableViewInsideCell.register(UINib(nibName: "TableViewCell", bundle: Bundle(for: type(of: self))), forCellReuseIdentifier: "TableViewCellId")
        self.tableViewInsideCell.reloadData()
    }
//TableViewCell
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController:UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellId") as! TableViewCell
        
    }
    
   
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellId1 = "cellId1"
        var cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cellId1") as! TableViewCell
        if (cell == nil) {
        self.tableViewInsideCell.register(UINib(nibName: "TableViewCell", bundle: Bundle(for: type(of: self))), forCellReuseIdentifier: "TableViewCellId")
        cell.tintColor = .blue
        cell.selectionStyle = .default
        cell.selectedBackgroundView = UIView()
        cell.selectedBackgroundView?.backgroundColor = .clear
        cell.selectedBackgroundView?.backgroundColor = .clear
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func  tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .none
    }
}

