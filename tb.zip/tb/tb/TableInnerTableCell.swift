//
//  TableInnerTableCell.swift
//  tb
//
//  Created by Salute on 20/11/16.
//  Copyright © 2016 RedSalute. All rights reserved.
//

import UIKit

class TableInnerTableCell: UITableViewCell,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var InnertableView: UITableView!

    @IBOutlet weak var CustomTitle: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.InnertableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.InnertableView.delegate = self
        self.InnertableView.dataSource = self
        
    }
//    init() {
//        super.init(style: UITableViewCellStyle.default, reuseIdentifier: "cellInner")
//    }
//    override init(style: UITableViewCellStyle, reuseIdentifier: String?){
//        super.init(style: style, reuseIdentifier: reuseIdentifier)
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("has not been implemented")
//    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
  
   //MARK : - UITableview datasource and delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellId = "cell"
        
        var cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath)
            
        
        if (cell == nil)  {
    cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: cellId)
       }
   cell.textLabel?.text = String(format : "Cell %ld - %ld",indexPath.section,indexPath.row
        )
        return cell

        
    }
    
}
