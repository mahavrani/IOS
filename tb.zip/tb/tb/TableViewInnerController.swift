//
//  TableViewInnerController.swift
//  tb
//
//  Created by Salute on 20/11/16.
//  Copyright © 2016 RedSalute. All rights reserved.
//

import UIKit

class TableViewInnerController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableview: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableview.register(UINib(nibName: "TableInnerTableCell", bundle: Bundle(for: type(of: self))), forCellReuseIdentifier:"InnerCell")
        
        print(NSStringFromClass(TableInnerTableCell.self))
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 6
//    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: TableInnerTableCell = tableView.dequeueReusableCell(withIdentifier: "InnerCell", for: indexPath) as! TableInnerTableCell
        cell.CustomTitle.text = String(format : "Table Number %ld",indexPath.row )
        cell.InnertableView.reloadData()
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = UIColor.brown
        } else {
            cell.backgroundColor = UIColor.blue
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
